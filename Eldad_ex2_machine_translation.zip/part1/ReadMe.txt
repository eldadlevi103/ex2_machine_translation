Instructions how to run it:
- make sure all the extracted files sitting at the same directory.
- press double click on "run_trainning_script.bat", 
at first it will start to download to your computer all the relvant libraris 
and then the model will start trainning.
# If you want to run the the same data that was suppllied in the moodle:
please ignore this step.
in case you want to use another train/dev/test data then what was supplied
in the moodle, put it in: data->multi30k , 
     - please give the names of dev.src/dev.trg the names: val.src/val.trg    
     - please give the names of test.src/test.trg the names: test2016.src/test2016.trg
     - I'm so sorry for this two steps, I used a library that apperantly very strict.
- After the trainning_script will finish, it will create a file called: "best-modle.pt"
- now you can press double click on "run_evaluation_script.bat" and it will run the evaluation script.

Hope everything is clear.
In any case, if something is not working or there are some problems, 
feel very free: 0508802904 or Eldadlevi103@gmail.com

Thanks, Eldad.
