import random
import math
import time
import sys
import spacy
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torchtext.legacy.datasets import Multi30k
from torchtext.legacy.data import Field, BucketIterator
from spacy.lang.en import English
from sacrebleu.metrics import BLEU

nlp = English()
START_S = '<sos>'
END_S = '<eos>'
BATCH_SIZE = 1
N_EPOCHS = 10
CLIP = 1


# I Used this guide for helping me:
# https://github.com/bentrevett/pytorch-seq2seq/blob/master/1%20-%20Sequence%20to%20Sequence%20Learning%20with%20Neural%20Networks.ipynb
# It helped me understand the material and to do the word
class Encoder(nn.Module):
    def __init__(self, input_dim, emb_dim, hid_dim, n_layers, dropout):
        super().__init__()  # using the parents

        self.n_layers = n_layers
        self.hid_dim = hid_dim

        self.dropout = nn.Dropout(dropout)
        self.rnn = nn.LSTM(emb_dim, hid_dim, n_layers, dropout=dropout)
        self.embedding = nn.Embedding(input_dim, emb_dim)

    def forward(self, src):
        embedded = self.dropout(self.embedding(src))
        outputs, (hidden, cell) = self.rnn(embedded)
        return hidden, cell


class Decoder(nn.Module):
    def __init__(self, output_dim, emb_dim, hid_dim, n_layers, dropout):
        super().__init__()

        self.n_layers = n_layers
        self.hid_dim = hid_dim
        self.output_dim = output_dim
        self.rnn = nn.LSTM(emb_dim, hid_dim, n_layers, dropout=dropout)
        self.dropout = nn.Dropout(dropout)
        self.fc_out = nn.Linear(hid_dim, output_dim)
        self.embedding = nn.Embedding(output_dim, emb_dim)

    def forward(self, input, hidden, cell):
        input = input.unsqueeze(0)
        embedded = self.dropout(self.embedding(input))
        output, (hidden, cell) = self.rnn(embedded, (hidden, cell))
        prediction = self.fc_out(output.squeeze(0))
        return prediction, hidden, cell


class Seq2Seq(nn.Module):
    def __init__(self, encoder, decoder, device):
        super().__init__()

        self.device = device
        self.decoder = decoder
        self.encoder = encoder

    def forward(self, src, trg, teacher_forcing_ratio=0.5):
        batch_size = trg.shape[1]
        trg_len = trg.shape[0]
        trg_vocab_size = self.decoder.output_dim

        outputs = torch.zeros(trg_len, batch_size, trg_vocab_size).to(self.device)

        hidden, cell = self.encoder(src)

        input = trg[0, :]

        for t in range(1, trg_len):
            output, hidden, cell = self.decoder(input, hidden, cell)

            outputs[t] = output

            teacher_force = random.random() < teacher_forcing_ratio

            top1 = output.argmax(1)

            input = trg[t] if teacher_force else top1

        return outputs


def tokenize_en(text):
    return [tok.text for tok in nlp.tokenizer(text)]


def init_weights(m):
    for name, param in m.named_parameters():
        nn.init.uniform_(param.data, -0.08, 0.08)


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def train(model, iterator, optimizer, criterion, clip):
    model.train()

    epoch_loss = 0

    for i, batch in enumerate(iterator):
        src = batch.src
        trg = batch.trg

        optimizer.zero_grad()

        output = model(src, trg)

        output_dim = output.shape[-1]

        output = output[1:].view(-1, output_dim)
        trg = trg[1:].view(-1)

        loss = criterion(output, trg)

        loss.backward()

        torch.nn.utils.clip_grad_norm_(model.parameters(), clip)

        optimizer.step()

        epoch_loss += loss.item()

    return epoch_loss / len(iterator)


def evaluate(model, iterator, criterion, TRG):
    model.eval()
    list_of_origin_translations = []
    list_of_predictions = []
    epoch_loss = 0

    with torch.no_grad():
        for i, batch in enumerate(iterator):
            trg = batch.trg
            src = batch.src

            output = model(src, trg, 0)

            output_dim = output.shape[-1]

            output = output[1:].view(-1, output_dim)

            prdicted = prophecy_to_result(output, TRG)
            prdicted = prdicted[:-5]  # erasing the<eof>
            list_of_predictions.append(prdicted)
            st = ""
            for element in batch.dataset.examples[i].trg:
                st += element
            list_of_origin_translations.append(st)

            trg = trg[1:].view(-1)

            loss = criterion(output, trg)

            epoch_loss += loss.item()

        blue_improvment = BLEU(max_ngram_order=2) #https://towardsdatascience.com/machine-translation-evaluation-with-sacrebleu-and-bertscore-d7fdb0c47eb3
        bl = blue_improvment.corpus_score(list_of_predictions, [list_of_origin_translations])

    return epoch_loss / len(iterator), bl


def load_data(data_path):
    data = []
    f = open(data_path, "r")
    for line in f:
        line = line.replace("\n", '')
        data.append(line)

    return data


def prophecy_to_result(predict, TRG):
    vocabulary = TRG.vocab.stoi
    from_ind_word = {id: word for word, id in vocabulary.items()}
    guess = ''
    for element in predict:
        p = torch.argmax(element).item()
        guess += from_ind_word[p]
    return guess


def main():
    print("evaluation Script !")

    # process the train data:
    SRC = Field(tokenize=tokenize_en,
                init_token=START_S,
                eos_token=END_S,
                lower=False)
    TRG = Field(tokenize=tokenize_en,
                init_token=START_S,
                eos_token=END_S,
                lower=False)
    train_data, valid_data, test_data = Multi30k.splits(exts=('.src', '.trg'),
                                                        fields=(SRC, TRG), root='data')

    SRC.build_vocab(train_data, min_freq=2)
    TRG.build_vocab(train_data, min_freq=2)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    train_iterator, valid_iterator, test_iterator = BucketIterator.splits(
        (train_data, valid_data, test_data),
        batch_size=BATCH_SIZE,
        device=device,
        sort=False)

    INPUT_DIM = len(SRC.vocab)
    OUTPUT_DIM = len(TRG.vocab)
    ENC_EMB_DIM = 256
    DEC_EMB_DIM = 256
    HID_DIM = 512
    N_LAYERS = 2
    ENC_DROPOUT = 0.5
    DEC_DROPOUT = 0.5

    enc = Encoder(INPUT_DIM, ENC_EMB_DIM, HID_DIM, N_LAYERS, ENC_DROPOUT)
    dec = Decoder(OUTPUT_DIM, DEC_EMB_DIM, HID_DIM, N_LAYERS, DEC_DROPOUT)

    model = Seq2Seq(enc, dec, device).to(device)
    model.apply(init_weights)

    TRG_PAD_IDX = TRG.vocab.stoi[TRG.pad_token]
    criterion = nn.CrossEntropyLoss(ignore_index=TRG_PAD_IDX)
    model.load_state_dict(torch.load('best-model.pt'))
    test_loss,bleu = evaluate(model, test_iterator, criterion,TRG)
    print("the test loss: " +str(test_loss))

    print(bleu)




if __name__ == "__main__":
    main()
